<?php 
header("Location: BitacoraMantenimiento/Bitacora.php");
?>
