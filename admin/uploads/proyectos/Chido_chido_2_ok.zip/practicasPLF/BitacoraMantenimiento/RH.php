<?php
require_once("RH.Controller.php");
include("header.php");
$datos = $rh->leer();
include("RH.View.php");
include("footer.php");
?>