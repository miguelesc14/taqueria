<h1 class="text-center">Área Financieros</h1>

<div class="container-fluid">
    <table class="table table-responsive table-bordered">
        <thead>
            <tr>
                <th scope="col">id mantenimiento</th>
                <th scope="col">nombre area</th>
                <th scope="col">id maquina</th>
                <th scope="col">correo</th>
                <th scope="col">fecha mantenimiento</th>
                <th scope="col">id maquina de repuesto</th>
                <th scope="col">estatus</th>
                <th scope="col">tipo</th>
                <th scope="col">materiales</th>
                <th scope="col">Operacion</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($datos as $key => $financieros): ?>
                <tr>
                    <td>
                        <?php echo $financieros["id_mantenimiento"] ?>
                    </td>
                    <td>
                        <?php echo $financieros["nombre_area"] ?>
                    </td>
                    <td>
                        <?php echo $financieros["id_maquina"] ?>
                    </td>
                    <td>
                        <?php echo $financieros["correo"] ?>
                    </td>
                    <td>
                        <?php echo $financieros["fecha_mantenimiento"] ?>
                    </td>
                    <td>
                        <?php echo $financieros["id_maquina_repuesto"] ?>
                    </td>
                    <td>
                        <?php echo $financieros["estatus"] ?>
                    </td>
                    <td>
                        <?php echo $financieros["tipo"] ?>
                    </td>
                    <td>
                        <?php echo $financieros["materiales"] ?>
                    </td>
                    <td>
                        <a class="btn btn-primary" href="alumnos.php?accion=actualizar&n_control=" role="button">Editar</a>
                        <a class="btn btn-danger" href="alumnos.php?accion=borrar&n_control=" role="button">Borrar</a>
                    </td>
                </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>