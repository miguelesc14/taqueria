<?php
require_once("Bitacora.Controller.php");
include("header.php");
$datos = $bita->historico();
include("Historico.View.php");
include("footer.php");
?>