<h1 class="text-center">Área de mantenimiento</h1>
<div class="container-fluid">
    <p><a class="btn btn-success" href="Mantenimiento.php?accion=crear" role="button">Nuevo Mantenimiento</a></p>


    <table class="table table-responsive table-bordered">
        <thead>
            <tr>
                <th scope="col">id_mantenimiento</th>
                <th scope="col">Area</th>
                <th scope="col">id máquina</th>
                <th scope="col">correo del usuario</th>
                <th scope="col">fecha del mantenimiento</th>
                <th scope="col">id máquina de repuesto</th>
                <th scope="col">Estado del mantenimiento</th>
                <th scope="col">Tipo de mantenimiento</th>
                <th scope="col">Operacion</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($datos as $key => $mantenimiento): ?>
                <tr>
                    <td>
                        <?php echo $mantenimiento["id_mantenimiento"] ?>
                    </td>
                    <td>
                        <?php echo $mantenimiento["nombre_area"] ?>
                    </td>
                    <td>
                        <?php echo $mantenimiento["id_maquina"] ?>
                    </td>
                    <td>
                        <?php echo $mantenimiento["correo"] ?>
                    </td>
                    <td>
                        <?php echo $mantenimiento["fecha_mantenimiento"] ?>
                    </td>
                    <td>
                        <?php echo $mantenimiento["id_maquina_repuesto"] ?>
                    </td>
                    <td>
                        <?php echo $mantenimiento["estatus"] ?>
                    </td>
                    <td>
                        <?php echo $mantenimiento["tipo"] ?>
                    </td>
                    <td>
                        <a class="btn btn-primary"
                            href="Mantenimiento.php?accion=actualizar&id_mantenimiento=<?php echo $mantenimiento["id_mantenimiento"] ?>"
                            role="button">Editar</a>
                        <a class="btn btn-danger"
                            href="Mantenimiento.php?accion=borrar&id_mantenimiento=<?php echo $mantenimiento["id_mantenimiento"] ?>"
                            role="button">Borrar</a>
                    </td>
                </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>