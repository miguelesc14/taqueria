<?php
require_once('Sistema.class.php');

class RH extends Sistema
{
    function leer()
    {
        $this->conexion(); //Conexion del metodo
        $sql = "SELECT * FROM area_rh ORDER BY estatus";
        $datos = $this->_CON->prepare($sql);
        $datos->execute();

        $datos = $datos->fetchAll(PDO::FETCH_ASSOC);
        return $datos;
    }
}
$rh = new RH;
?>