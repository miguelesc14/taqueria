<h1 class="text-center">Máquinas existentes por área</h1>

<div class="container-fluid">
    <table class="table table-responsive table-bordered">
        <thead>
            <tr>
                <th scope="col">id máquina</th>
                <th scope="col">número de serie</th>
                <th scope="col">marca</th>
                <th scope="col">área</th>
                <th scope="col">id máquina de repuesto</th>
                <th scope="col">usuario</th>
                <th scope="col">Operacion</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($datos as $key => $maquina): ?>
                <tr>
                    <td>
                        <?php echo $maquina["id_maquina"] ?>
                    </td>
                    <td>
                        <?php echo $maquina["n_serie"] ?>
                    </td>
                    <td>
                        <?php echo $maquina["marca"] ?>
                    </td>
                    <td>
                        <?php echo $maquina["nombre_area"] ?>
                    </td>
                    <td>
                        <?php echo $maquina["id_maquina_repuesto"] ?>
                    </td>
                    <td>
                        <?php echo $maquina["correo"] ?>
                    </td>
                    <td>
                        <a class="btn btn-primary" href="alumnos.php?accion=actualizar&n_control=" role="button">Editar</a>
                        <a class="btn btn-danger" href="alumnos.php?accion=borrar&n_control=" role="button">Borrar</a>
                    </td>
                </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>