<?php
require_once('Sistema.class.php');

class Estatus extends Sistema
{
    function leer()
    {
        $this->conexion(); //Conexion del metodo
        $sql = "SELECT * FROM estatus";
        $datos = $this->_CON->prepare($sql);
        $datos->execute();

        $datos = $datos->fetchAll(PDO::FETCH_ASSOC);
        return $datos;
    }
}

$esta = new Estatus;

?>