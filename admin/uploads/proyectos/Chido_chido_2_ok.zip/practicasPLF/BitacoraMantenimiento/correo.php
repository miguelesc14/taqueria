<?php
require("../PHPMailer/Exception.php");
require("../PHPMailer/PHPMailer.php");
require("../PHPMailer/SMTP.php");
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function enviarCorreo ($remitente, $destinatario, $encabezado, $mensaje, $fecha) {
    $oMail = new PHPMailer();
    $oMail->isSMTP();
    $oMail->Host = "smtp.gmail.com";
    $oMail->Port = 587;
    $oMail->SMTPSecure = "tls";
    $oMail->SMTPAuth = true;
    $oMail->Username = "freddy024.pixelart@gmail.com";
    $oMail->Password = "tgmyxfwjempiltml";
    $oMail->setFrom("freddy024.pixelart@gmail.com", "Freddy AG");
    $oMail->addAddress($destinatario, $destinatario);
    $oMail->Subject = $encabezado;
    $oMail->msgHTML("Tu mantenimiento de tu máquina se realizará el: ". $fecha);

    if (!$oMail->send()) {
        echo $oMail->ErrorInfo;
    }
}


    ?>