<?php
require_once('Sistema.class.php');

class Maquina extends Sistema
{

    
    
    function leerview()
    {
        $this->conexion(); //Conexion del metodo
        $sql = "SELECT * FROM maquinas_view ORDER BY nombre_area ";
        $datos = $this->_CON->prepare($sql);
        $datos->execute();

        $datos = $datos->fetchAll(PDO::FETCH_ASSOC);
        return $datos;
    }

    function leer(){
        $this->conexion(); //Conexion del metodo
        $sql = "SELECT * FROM maquina ORDER BY id_maquina ";
        $datos = $this->_CON->prepare($sql);
        $datos->execute();

        $datos = $datos->fetchAll(PDO::FETCH_ASSOC);
        return $datos;
    }

}
$maqui = new Maquina;
?>