<!doctype html>
<html lang="es">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css"
    integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

  <title>Bitacora</title>
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#">Navbar</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup"
      aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-item nav-link" href="Bitacora.php">Bitacora</a>
        <a class="nav-item nav-link" href="Mantenimiento.php">Mantenimiento</a>
        <a class="nav-item nav-link" href="Produccion.php">Producción</a>
        <a class="nav-item nav-link" href="RH.php">Recursos Humanos</a>
        <a class="nav-item nav-link" href="Financiero.php">Financieros</a>
        <a class="nav-item nav-link" href="Maquinas.php">Máquinas</a>
        <a class="nav-item nav-link" href="Historico.php">Histórico</a>
      </div>
    </div>
  </nav>