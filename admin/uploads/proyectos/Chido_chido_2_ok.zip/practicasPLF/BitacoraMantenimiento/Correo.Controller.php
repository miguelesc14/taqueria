<?php
require_once('Sistema.class.php');

class Correo extends Sistema
{
    function obtenerCorreosPendiente()
    {
        $this->conexion(); //Conexion del metodo
        $sql = "SELECT * FROM correos_mant_pend_7d_view ORDER BY correo";
        $datos = $this->_CON->prepare($sql);
        $datos->execute();

        $datos = $datos->fetchAll(PDO::FETCH_ASSOC);
        return $datos;
    }
}
$correo = new Correo;
?>