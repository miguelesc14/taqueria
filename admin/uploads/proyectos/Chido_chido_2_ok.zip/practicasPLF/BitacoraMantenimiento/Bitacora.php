<?php
require_once("Bitacora.Controller.php");
require_once("estatus.controller.php");
require_once("tipo.controller.php");
require_once("Maquinas.Controller.php");

$accion = (isset($_GET["accion"])) ? $_GET["accion"] : null;

include("header.php");

$datose = $esta->leer();
$datost = $tipObj->leer();
$datosm = $maqui->leer();

switch ($accion) {
    case 'crear':
        if (isset($_POST["guardar"])) {
            $data = $_POST;
            $nuevos = $bita->crear($data);
            $datos = $bita->leer();
            include("Bitacora.View.php");
        } else {
            include("Bitacora.Form.php");
        }
        break;
    case 'borrar':
        $id_mantenimiento = (isset($_GET["id_mantenimiento"])) ? $_GET["id_mantenimiento"] : null;
        $borrados = $bita->borrar($id_mantenimiento);

        $datos = $bita->leer();
        include("Bitacora.View.php");
        break;
    case 'actualizar':
        if (isset($_POST["guardar"])) {
            $data = $_POST;
            $actualizar = $bita->actualizar($data["id_mantenimiento_old"], $data);

            $datos = $bita->leer();

            include("Bitacora.View.php");
        } else {
            $id_mantenimiento = (isset($_GET["id_mantenimiento"])) ? $_GET["id_mantenimiento"] : null;
            $datos = $bita->leeruno($id_mantenimiento);
            include("Bitacora.Form.php");
        }
        break;
    case 'leer':
    default:
        $datos = $bita->leer();
        include("Bitacora.View.php");
        break;
}
include("footer.php");
?>