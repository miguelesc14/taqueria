<?php
require_once('Sistema.class.php');

class Tipo extends Sistema
{
    function leer()
    {
        $this->conexion(); //Conexion del metodo
        $sql = "SELECT * FROM tipo";
        $datos = $this->_CON->prepare($sql);
        $datos->execute();

        $datos = $datos->fetchAll(PDO::FETCH_ASSOC);
        return $datos;
    }
}

$tipObj = new Tipo;

?>