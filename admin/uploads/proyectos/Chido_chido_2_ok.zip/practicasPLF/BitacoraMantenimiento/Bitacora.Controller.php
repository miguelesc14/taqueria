<?php
require_once('Sistema.class.php');

class Bitacora extends Sistema
{

    function crear($data)
    {
        $datos = 0;

        $id_matenimiento = $data["id_mantenimiento"];

        $id_maquina = $data["id_maquina"];
        $fecha = $data["fecha"];
        $id_estatus = $data["id_estatus"];
        $id_tipo = $data["id_tipo"];
        $materiales = $data["materiales"];

        if ($data["id_mantenimiento"] == "") {
            $sql = "INSERT INTO mantenimiento (id_maquina, fecha, id_estatus, id_tipo) 
        VALUES (:id_maquina, :fecha, :id_estatus, :id_tipo)";
            $this->conexion(); //Conexion del metodo
            $sentencia = $this->_CON->prepare($sql);
            $sentencia->bindParam("id_maquina", $id_maquina);
            $sentencia->bindParam("fecha", $fecha);
            $sentencia->bindParam("id_estatus", $id_estatus);
            $sentencia->bindParam("id_tipo", $id_tipo);
            $sentencia->bindParam("materiales", $materiales);
        } else {
            $sql = "INSERT INTO mantenimiento (id_mantenimiento, id_maquina, fecha, id_estatus, id_tipo, materiales) 
            VALUES (:id_mantenimiento, :id_maquina, :fecha, :id_estatus, :id_tipo, :materiales)";

            $sentencia = $this->_CON->prepare($sql);
            $sentencia->bindParam("id_mantenimiento", $id_matenimiento);
            $sentencia->bindParam("id_maquina", $id_maquina);
            $sentencia->bindParam("fecha", $fecha);
            $sentencia->bindParam("id_estatus", $id_estatus);
            $sentencia->bindParam("id_tipo", $id_tipo);
            $sentencia->bindParam("materiales", $materiales);
        }
    }

    function leer()
    {
        $this->conexion(); //Conexion del metodo
        $sql = "SELECT * FROM bitacora ORDER BY estatus ";
        $datos = $this->_CON->prepare($sql);
        $datos->execute();

        $datos = $datos->fetchAll(PDO::FETCH_ASSOC);
        return $datos;
    }

    function borrar($id_mantenimiento)
    {
        $datos = 0;
        if (!is_null($id_mantenimiento)) {
            $this->conexion(); //Conexion del metodo
            $sql = "DELETE FROM mantenimiento WHERE id_mantenimiento=:id_mantenimiento";
            $sentencia = $this->_CON->prepare($sql);
            $sentencia->bindParam("id_mantenimiento", $id_mantenimiento);
            $sentencia->execute();
            $datos = $sentencia->rowCount();
        }
        return $datos;
    }

    function actualizar($id_matenimiento_old, $data)
    {
        $datos = 0;
        if (!is_null($id_matenimiento_old)) {
            $this->conexion(); //Conexion del metodo
            $sql = "UPDATE mantenimiento set id_mantenimiento=:id_mantenimiento, id_maquina=:id_maquina, fecha=:fecha, id_estatus=:id_estatus, id_tipo=:id_tipo
            , materiales=:materiales
             WHERE id_mantenimiento=:id_mantenimiento_old";
            $sentencia = $this->_CON->prepare($sql);
            $sentencia->bindParam("id_mantenimiento", $data["id_mantenimiento"]);
            $sentencia->bindParam("id_maquina", $data["id_maquina"]);
            $sentencia->bindParam("fecha", $data["fecha"]);
            $sentencia->bindParam("id_estatus", $data["id_estatus"]);
            $sentencia->bindParam("id_tipo", $data["id_tipo"]);
            $sentencia->bindParam("materiales", $data["materiales"]);
            $sentencia->bindParam("id_mantenimiento_old", $id_matenimiento_old);
            $sentencia->execute();
            $datos = $sentencia->rowCount();
        }
        return $datos;
    }

    function leeruno($id_mantenimiento)
    {
        $datos = null;
        if (!is_null($id_mantenimiento)) {
            $this->conexion(); //Conexion del metodo
            $sql = "SELECT * FROM mantenimiento WHERE id_mantenimiento=:id_mantenimiento";
            $datos = $this->_CON->prepare($sql);
            $datos->bindParam("id_mantenimiento", $id_mantenimiento);
            $datos->execute();

            $datos = $datos->fetchAll(PDO::FETCH_ASSOC);
            $datos = $datos[0];

        }
        return $datos;
    }

    function historico()
    {
        $this->conexion(); //Conexion del metodo
        $sql = "SELECT * FROM historico order by fecha";
        $datos = $this->_CON->prepare($sql);
        $datos->execute();

        $datos = $datos->fetchAll(PDO::FETCH_ASSOC);
        return $datos;
    }
}
$bita = new Bitacora;
?>