<h1 class="text-center">Histórico de los mantenimientos</h1>

<div class="container-fluid">
    <table class="table table-responsive table-bordered">
        <thead>
            <tr>
                <th scope="col">id_historico</th>
                <th scope="col">fecha de eliminación</th>
                <th scope="col">datos eliminados</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($datos as $key => $mantenimiento): ?>
                <tr>
                    <td>
                        <?php echo $mantenimiento["id_historico"] ?>
                    </td>
                    <td>
                        <?php echo $mantenimiento["fecha"] ?>
                    </td>
                    <td>
                        <?php echo $mantenimiento["data_viejo"] ?>
                    </td>
                </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>