<?php
class Sistema
{

    var $_CON = null;

    function conexion()
    {
        $this->_CON = new PDO('mysql:host=localhost;dbname=id20402757_mantenimiento', 'id20402757_adminmantenimiento', 'w9{+00#t*hEIr>YZ');
        //$this->_CON = new PDO('mysql:host=localhost;dbname=Mantenimiento', 'adminMantenimiento', '123');
    }
}
?>