<?php
require_once("Financiero.Controller.php");
include("header.php");
$datos = $finan->leer();
include("Financiero.View.php");
include("footer.php");
?>