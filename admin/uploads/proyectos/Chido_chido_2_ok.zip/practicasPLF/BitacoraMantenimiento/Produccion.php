<?php
require_once("Produccion.Controller.php");
include("header.php");
$datos = $prod->leer();
include("Produccion.View.php");
include("footer.php");
?>