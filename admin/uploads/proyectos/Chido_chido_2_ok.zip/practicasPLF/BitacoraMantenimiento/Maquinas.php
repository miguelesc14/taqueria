<?php
require_once("Maquinas.Controller.php");
include("header.php");
$datos = $maqui->leerview();
include("Maquinas.View.php");
include("footer.php");
?>