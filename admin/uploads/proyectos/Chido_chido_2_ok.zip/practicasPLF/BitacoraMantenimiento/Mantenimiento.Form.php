<h1 class="text-center">Datos del Matenimiento</h1>

<div class="container-fluid">
    <form class="container-fluid" method="POST" action="Mantenimiento.php?accion=<?php echo ($accion); ?>"
        enctype="multipart/form-data">

        <div class="row">
            <div class="col-2">
                <label for="id_mantenimiento" class="visually-hidden form-text">id_mantenimiento:
                </label>
            </div>
        </div>

        <div class="row">
            <div class="col-2">
                <input type="number" class="" id="id_mantenimiento" name="id_mantenimiento"
                    value="<?php echo (isset($datos["id_mantenimiento"])) ? $datos["id_mantenimiento"] : ""; ?>">
            </div>
        </div>

        <div class="row">
            <div class="col-2">
                <label for="id_maquina" class="visually-hidden form-text">id_maquina:
                </label>
            </div>
        </div>

        <div class="row">
            <div class="col-2">
                <input required="required" type="number" class="" id="id_maquina" name="id_maquina"
                    value="<?php echo (isset($datos["id_maquina"])) ? $datos["id_maquina"] : ""; ?>">
            </div>
        </div>

        <div class="row">
            <div class="col-2">
                <label for="fecha" class="visually-hidden">Fecha:</label>
            </div>
        </div>
        <div class="row">
            <div class="col-2">
                <input required="required" type="date" class="" id="fecha" name="fecha"
                    value="<?php echo (isset($datos["fecha"])) ? $datos["fecha"] : ""; ?>">
            </div>
        </div>

        <div class="row">
            <p></p>
        </div>

        <div class="row">
            <div class="col-2">
                <label for="id_estatus" class="visually-hidden">id_estatus:</label>
            </div>
        </div>

        <div class="row">
            <div class="col-2">
                <input required="required" type="number" class="" id="id_estatus" name="id_estatus"
                    value="<?php echo (isset($datos["id_estatus"])) ? $datos["id_estatus"] : ""; ?>">
            </div>
        </div>

        <div class="row">
            <div class="col-2">
                <label for="id_tipo" class="visually-hidden">id_tipo:</label>
            </div>
        </div>

        <div class="row">
            <div class="col-2">
                <input required="required" type="number" class="" id="id_tipo" name="id_tipo"
                    value="<?php echo (isset($datos["id_tipo"])) ? $datos["id_tipo"] : ""; ?>">
            </div>
        </div>

        <div class="row">
            <p></p>
        </div>


        <div class="row">
            <div class="col-12">
                <input type="submit" class="btn btn-primary mb-3" name="guardar" value="Guardar">
            </div>
        </div>

        <?php if ($accion == "actualizar"): ?>
            <input type="hidden" name="id_mantenimiento_old" value="<?php echo $datos["id_mantenimiento"]; ?>" />
        <?php endif; ?>
    </form>
</div>