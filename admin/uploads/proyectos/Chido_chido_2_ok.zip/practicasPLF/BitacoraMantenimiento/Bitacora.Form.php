<h1 class="text-center">Datos del Matenimiento</h1>

<div class="container-fluid">
    <form method="POST" action="Bitacora.php?accion=<?php echo ($accion); ?>" enctype="multipart/form-data">

        <div class="row">
            <div class="col-2">
                <label for="id_mantenimiento" class="visually-hidden form-text">Id mantenimiento:
                </label>
            </div>
        </div>

        <div class="row">
            <div class="col-2">
                <input type="number" class="" id="id_mantenimiento" name="id_mantenimiento"
                    value="<?php echo (isset($datos["id_mantenimiento"])) ? $datos["id_mantenimiento"] : ""; ?>">
            </div>
        </div>

        <div class="row">
            <div class="col-2">
                <label for="id_maquina" class="visually-hidden form-text">Máquina:
                </label>
            </div>
        </div>

        <div class="row">
            <div class="col-2">
                <select id="id_maquina" name="id_maquina" required="required">
                    <?php
                    foreach ($datosm as $key => $maquina):
                        if (isset($datos["id_maquina"]) && $maquina["id_maquina"] == $datos["id_maquina"]) {
                            echo '<option selected="selected" value="' . $maquina["id_maquina"] . '">' . $maquina["nombre"] . '</option>';
                        } else {
                            echo '<option value="' . $maquina["id_maquina"] . '">' . $maquina["nombre"] . '</option>';
                        }
                    endforeach
                    ?>
                </select>
            </div>
        </div>

        <div class="row">
            <div class="col-2">
                <label for="fecha" class="visually-hidden">Fecha:</label>
            </div>
        </div>
        <div class="row">
            <div class="col-2">
                <input required="required" type="date" class="" id="fecha" name="fecha"
                    value="<?php echo (isset($datos["fecha"])) ? $datos["fecha"] : ""; ?>">
            </div>
        </div>

        <div class="row">
            <p></p>
        </div>

        <div class="row">
            <div class="col-3">
                <label for="id_estatus" class="visually-hidden">Estatus del mantenimiento:</label>
            </div>
        </div>

        <div class="row">
            <div class="col-2">
                <select id="id_estatus" name="id_estatus" required="required">
                    <?php foreach ($datose as $key => $estatus):
                        if (isset($datos["id_estatus"]) && $estatus["id_estatus"] == $datos["id_estatus"]) {
                            echo '<option selected="selected" value="' . $estatus["id_estatus"] . '">' . $estatus["estatus"] . '</option>';
                        } else {
                            echo '<option value="' . $estatus["id_estatus"] . '">' . $estatus["estatus"] . '</option>';
                        }
                    endforeach
                    ?>
                </select>
            </div>
        </div>

        <div class="row">
            <div class="col-2">
                <label for="id_tipo" class="visually-hidden">Tipo de mantenimiento:</label>
            </div>
        </div>

        <div class="row">
            <div class="col-2">
                <select id="id_tipo" name="id_tipo" required="required">
                    <?php foreach ($datost as $key => $tipo):
                        if (isset($datos["id_tipo"]) && $tipo["id_tipo"] == $datos["id_tipo"]) {
                            echo '<option selected="selected" value="' . $tipo["id_tipo"] . '">' . $tipo["tipo"] . '</option>';
                        } else {
                            echo '<option value="' . $tipo["id_tipo"] . '">' . $tipo["tipo"] . '</option>';
                        }
                    endforeach
                    ?>
                </select>
            </div>
        </div>

        <div class="row">
            <p></p>
        </div>

        <div class="row">
            <div class="col-2">
                <label for="materiales" class="visually-hidden">Materiales:</label>
            </div>
        </div>

        <div class="row">
            <div class="col-2">
                <textarea id="materiales" name="materiales" rows="4" cols="25"
                    maxlength="250"><?php echo (isset($datos["materiales"])) ? $datos["materiales"] : ""; ?></textarea>
            </div>
        </div>

        <div class="row">
            <p></p>
        </div>


        <div class="row">
            <div class="col-12">
                <input type="submit" class="btn btn-primary mb-3" name="guardar" value="Guardar">
            </div>
        </div>

        <?php if ($accion == "actualizar"): ?>
            <input type="hidden" name="id_mantenimiento_old" value="<?php echo $datos["id_mantenimiento"]; ?>" />
        <?php endif; ?>
    </form>
</div>