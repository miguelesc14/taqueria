<?php
require_once('correo.php');
require_once('Correo.Controller.php');

$datos = $correo->obtenerCorreosPendiente();

$contador = 0;
foreach ($datos as $key => $mantenimiento):
    enviarCorreo("", $datos[$contador]["correo"], "Mantenimiento Pendiente en 1 semana", "", $datos[$contador]["fecha"]);
    $contador++;
endforeach;

?>