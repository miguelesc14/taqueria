<?php
require_once("Mantenimiento.Controller.php");

$accion = (isset($_GET["accion"])) ? $_GET["accion"] : null;

include("header.php");
switch ($accion) {
    case 'crear':
        if (isset($_POST["guardar"])) {
            $data = $_POST;
            $nuevos = $mante->crear($data);
            $datos = $mante->leer();
            include("Mantenimiento.View.php");
        } else {
            include("Mantenimiento.Form.php");
        }
        break;
    case 'borrar':
        $id_mantenimiento = (isset($_GET["id_mantenimiento"])) ? $_GET["id_mantenimiento"] : null;
        $borrados = $mante->borrar($id_mantenimiento);

        $datos = $mante->leer();
        include("Mantenimiento.View.php");
        break;
    case 'actualizar':
        if (isset($_POST["guardar"])) {
            $data = $_POST;
            $actualizar = $mante->actualizar($data["id_mantenimiento_old"], $data);

            $datos = $mante->leer();

            include("Mantenimiento.View.php");
        } else {
            $id_mantenimiento = (isset($_GET["id_mantenimiento"])) ? $_GET["id_mantenimiento"] : null;
            $datos = $mante->leeruno($id_mantenimiento);
            include("Mantenimiento.Form.php");
        }
        $id_mantenimiento = (isset($_GET["id_mantenimiento"])) ? $_GET["id_mantenimiento"] : null;
        $datos = $mante->leeruno($id_mantenimiento);
        break;
    case 'leer':
    default:
        $datos = $mante->leer();
        include("Mantenimiento.View.php");
        break;
}

include("footer.php");
?>