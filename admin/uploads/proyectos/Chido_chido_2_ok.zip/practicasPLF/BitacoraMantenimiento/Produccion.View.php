<h1 class="text-center">Área Producción</h1>

<div class="container-fluid">
    <table class="table table-responsive table-bordered">
        <thead>
            <tr>
                <th scope="col">id mantenimiento</th>
                <th scope="col">nombre area</th>
                <th scope="col">id maquina</th>
                <th scope="col">correo</th>
                <th scope="col">fecha mantenimiento</th>
                <th scope="col">id maquina de repuesto</th>
                <th scope="col">estatus</th>
                <th scope="col">tipo</th>
                <th scope="col">Operacion</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($datos as $key => $prod): ?>
                <tr>
                    <td>
                        <?php echo $prod["id_mantenimiento"] ?>
                    </td>
                    <td>
                        <?php echo $prod["nombre_area"] ?>
                    </td>
                    <td>
                        <?php echo $prod["id_maquina"] ?>
                    </td>
                    <td>
                        <?php echo $prod["correo"] ?>
                    </td>
                    <td>
                        <?php echo $prod["fecha_mantenimiento"] ?>
                    </td>
                    <td>
                        <?php echo $prod["id_maquina_repuesto"] ?>
                    </td>
                    <td>
                        <?php echo $prod["estatus"] ?>
                    </td>
                    <td>
                        <?php echo $prod["tipo"] ?>
                    </td>
                    <td>
                        <a class="btn btn-primary" href="alumnos.php?accion=actualizar&n_control=" role="button">Editar</a>
                        <a class="btn btn-danger" href="alumnos.php?accion=borrar&n_control=" role="button">Borrar</a>
                    </td>
                </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>