<h1 class="text-center">Bitácora</h1>
<div class="container-fluid">
    <div class="row">
        <div class="col-3">
            <p><a class="btn btn-success" href="Bitacora.php?accion=crear" role="button">Programar Nuevo
                    Mantenimiento</a></p>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <table class="table table-responsive table-bordered">
                <thead>
                    <tr>
                        <th scope="col">id mantenimiento</th>
                        <th scope="col">nombre area</th>
                        <th scope="col">id máquina</th>
                        <th scope="col">correo/usuario</th>
                        <th scope="col">fecha mantenimiento</th>
                        <th scope="col">id máquina de repuesto</th>
                        <th scope="col">estatus</th>
                        <th scope="col">tipo</th>
                        <th scope="col">materiales</th>
                        <th scope="col">operación</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($datos as $key => $bitacora): ?>
                        <tr>
                            <td>
                                <?php echo $bitacora["id_mantenimiento"] ?>
                            </td>
                            <td>
                                <?php echo $bitacora["nombre_area"] ?>
                            </td>
                            <td>
                                <?php echo $bitacora["id_maquina"] ?>
                            </td>
                            <td>
                                <?php echo $bitacora["correo"] ?>
                            </td>
                            <td>
                                <?php echo $bitacora["fecha_mantenimiento"] ?>
                            </td>
                            <td>
                                <?php echo $bitacora["id_maquina_repuesto"] ?>
                            </td>
                            <td>
                                <?php echo $bitacora["estatus"] ?>
                            </td>
                            <td>
                                <?php echo $bitacora["tipo"] ?>
                            </td>
                            <td>
                                <?php echo $bitacora["materiales"] ?>
                            </td>
                            <td>
                                <a class="btn btn-primary"
                                    href="Bitacora.php?accion=actualizar&id_mantenimiento=<?php echo $bitacora["id_mantenimiento"] ?>"
                                    role="button">Editar</a>
                                <a class="btn btn-danger"
                                    href="Bitacora.php?accion=borrar&id_mantenimiento=<?php echo $bitacora["id_mantenimiento"] ?>"
                                    role="button">Borrar</a>
                            </td>
                        </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        </div>
    </div>
</div>